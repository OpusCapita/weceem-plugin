grails.project.dependency.resolution = {
    inherits "global" // inherit Grails default dependencies
    
    dependencies {
        //compile "commons-codec:commons-codec:1.3"
        compile 'org.apache.ant:ant:1.7.1'
        compile 'org.apache.ant:ant-launcher:1.7.1'
    }
}