package org.weceem.content

class ContentReference {
    String referringProperty
    Content referencingContent
    Content targetContent
}