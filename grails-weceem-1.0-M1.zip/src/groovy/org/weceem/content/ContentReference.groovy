package org.weceem.content

class ContentReference {
    String referringProperty
    WcmContent referencingContent
    WcmContent targetContent
}