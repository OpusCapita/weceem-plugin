package org.weceem.export

/**
 * ImportException.
 *
 * @author Sergei Shushkevich
 */
class ImportException extends Exception {

    ImportException(String message) {
        super(message)
    }
}
