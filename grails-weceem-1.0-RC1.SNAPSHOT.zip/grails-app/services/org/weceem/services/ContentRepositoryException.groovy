package org.weceem.services

class ContentRepositoryException extends RuntimeException {
    ContentRepositoryException(String message) {
        super(message)
    }
}