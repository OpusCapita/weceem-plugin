editArea.add_lang("zh",{
test_select: "选择标签",
test_but: "测试按钮"
});
