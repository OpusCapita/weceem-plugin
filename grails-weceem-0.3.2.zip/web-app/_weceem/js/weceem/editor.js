
$( function() {
    $('#panels').accordion({
        collapsible: true,
        active: false
    })
})