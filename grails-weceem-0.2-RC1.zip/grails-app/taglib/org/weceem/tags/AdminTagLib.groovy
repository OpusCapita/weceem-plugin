package org.weceem.tags

class AdminTagLib { 
    static namespace = "wcm"
    
}