package org.weceem.blog

import org.weceem.content.Content

/**
 * Placeholder for blog settings etc, has BlogEntry children
 */
class Blog extends Content {

    static transients = Content.transients
    
}