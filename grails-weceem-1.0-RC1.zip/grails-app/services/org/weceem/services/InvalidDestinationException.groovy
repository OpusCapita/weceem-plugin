package org.weceem.services

class InvalidDestinationException extends ContentRepositoryException {
    InvalidDestinationException(String message) {
        super(message)
    }
}